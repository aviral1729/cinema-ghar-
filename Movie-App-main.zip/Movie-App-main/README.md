A Simple Movie Application using React JS ,allows the user to search and filter movies they want  from the MovieDB API

For UI creation HTML5 and CSS3 and material-UI are used

This is a responsive web application for viewing in both Mobile and Desktop.
